package com.example.crystalguard

import android.content.Context
import android.graphics.Canvas
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.min

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {
    private val game = Game(context)
    private val renderer = Renderer(game)

    // كل عنصر: [x, y, النوع]  النوع 0 = لمسة، 1 = زر رجوع
    private val events = ConcurrentLinkedQueue<FloatArray>()

    @Volatile private var running = false
    private var thread: Thread? = null

    @Volatile private var sw = 0
    @Volatile private var sh = 0
    @Volatile private var scale = 1f
    @Volatile private var offX = 0f
    @Volatile private var offY = 0f

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {}

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        sw = width
        sh = height
        scale = min(width / Game.W, height / Game.H)
        offX = (width - Game.W * scale) / 2f
        offY = (height - Game.H * scale) / 2f
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {}

    fun resume() {
        if (running) return
        running = true
        thread = Thread(this, "game-loop").also { it.start() }
    }

    fun pause() {
        running = false
        try { thread?.join() } catch (e: InterruptedException) {}
        thread = null
        game.onAppPause()
    }

    /** يعيد true إذا عالجت اللعبة زر الرجوع. */
    fun handleBack(): Boolean {
        if (game.state == Game.State.MENU) return false
        events.add(floatArrayOf(0f, 0f, 1f))
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            events.add(floatArrayOf((e.x - offX) / scale, (e.y - offY) / scale, 0f))
        }
        return true
    }

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            var dt = (now - last) / 1e9f
            last = now
            if (dt > 0.05f) dt = 0.05f

            if (!holder.surface.isValid || sw == 0) {
                try { Thread.sleep(30) } catch (e: InterruptedException) {}
                continue
            }

            while (true) {
                val ev = events.poll() ?: break
                if (ev[2] == 1f) game.onBack() else game.onTap(ev[0], ev[1])
            }

            val steps = if (game.state == Game.State.PLAYING) game.speed else 1
            repeat(steps) { game.update(dt) }

            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) renderer.draw(canvas, scale, offX, offY)
            } catch (e: Exception) {
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas) } catch (e: Exception) {}
                }
            }

            val spent = (System.nanoTime() - now) / 1_000_000
            if (spent < 16) {
                try { Thread.sleep(16 - spent) } catch (e: InterruptedException) {}
            }
        }
    }
}
