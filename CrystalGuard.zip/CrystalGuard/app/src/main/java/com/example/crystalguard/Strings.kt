package com.example.crystalguard

import java.util.Locale

/** نصوص الواجهة: عربي إذا كانت لغة الجهاز عربية، وإلا إنجليزي. */
object T {
    private val ar = Locale.getDefault().language == "ar"
    private fun s(en: String, a: String) = if (ar) a else en

    val title = s("Crystal Guard", "حراس البلورة")
    val choose = s("Choose a level", "اختر مرحلة")
    val nextWave = s("Next Wave", "الموجة التالية")
    val paused = s("Paused", "متوقف مؤقتًا")
    val resume = s("Resume", "استئناف")
    val restart = s("Restart", "إعادة اللعب")
    val menu = s("Menu", "القائمة")
    val victory = s("Victory!", "النصر!")
    val defeat = s("Defeat", "الهزيمة")
    val nextLevel = s("Next Level", "المرحلة التالية")
    val retry = s("Retry", "حاول مجددًا")
    val upgrade = s("Upgrade", "ترقية")
    val sell = s("Sell", "بيع")
    val maxed = s("MAX", "أقصى مستوى")
    val hint = s("Tap a stone pad to build a tower", "المس منصة حجرية لبناء برج")
    val dmg = s("DMG", "الضرر")
    val rng = s("RNG", "المدى")

    fun wave(n: Int, total: Int) = if (ar) "الموجة $n/$total" else "Wave $n/$total"
    fun lv(n: Int) = if (ar) "مستوى $n" else "Lv $n"

    fun tower(t: TowerType) = when (t) {
        TowerType.ARCHER -> s("Archer", "رامي")
        TowerType.CANNON -> s("Cannon", "مدفع")
        TowerType.FROST -> s("Frost", "صقيع")
        TowerType.MAGE -> s("Mage", "ساحر")
    }
}
