package com.example.crystalguard

import android.graphics.PointF
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

// ───────────────────────── الأبراج ─────────────────────────
// عدّل الأرقام هنا لضبط التوازن (cost = تكلفة البناء ثم تكلفة كل ترقية)

data class TowerStats(
    val cost: Int,
    val damage: Float,
    val range: Float,
    val cooldown: Float,
    val splash: Float = 0f,
    val slow: Float = 0f,
    val chain: Int = 1
)

enum class TowerType(val color: Int, val hitsAir: Boolean, val levels: List<TowerStats>) {
    ARCHER(
        0xFF8D6E4A.toInt(), true, listOf(
            TowerStats(70, 12f, 170f, 0.60f),
            TowerStats(90, 20f, 185f, 0.55f),
            TowerStats(130, 32f, 200f, 0.45f)
        )
    ),
    CANNON(
        0xFF546E7A.toInt(), false, listOf(
            TowerStats(110, 30f, 150f, 1.6f, splash = 60f),
            TowerStats(140, 52f, 160f, 1.5f, splash = 70f),
            TowerStats(200, 85f, 170f, 1.4f, splash = 80f)
        )
    ),
    FROST(
        0xFF4FC3F7.toInt(), true, listOf(
            TowerStats(90, 5f, 140f, 0.9f, splash = 45f, slow = 0.40f),
            TowerStats(100, 9f, 150f, 0.8f, splash = 45f, slow = 0.50f),
            TowerStats(140, 15f, 160f, 0.7f, splash = 45f, slow = 0.60f)
        )
    ),
    MAGE(
        0xFF9C27B0.toInt(), true, listOf(
            TowerStats(130, 22f, 160f, 1.1f, chain = 3),
            TowerStats(150, 36f, 170f, 1.0f, chain = 4),
            TowerStats(210, 55f, 180f, 0.9f, chain = 5)
        )
    );
}

// ───────────────────────── الأعداء ─────────────────────────

enum class EnemyType(
    val hp: Float, val speed: Float, val reward: Int, val damage: Int,
    val flying: Boolean, val radius: Float, val color: Int
) {
    GRUNT(60f, 60f, 8, 1, false, 16f, 0xFF66BB6A.toInt()),
    RUNNER(40f, 115f, 6, 1, false, 13f, 0xFFFFCA28.toInt()),
    TANK(320f, 38f, 25, 2, false, 22f, 0xFF8D6E63.toInt()),
    FLYER(70f, 80f, 12, 1, true, 15f, 0xFFEF5350.toInt()),
    BOSS(1500f, 32f, 150, 6, false, 30f, 0xFF6A1B9A.toInt())
}

// ───────────────────────── المراحل ─────────────────────────

class LevelDef(
    val seed: Int,
    val path: List<PointF>,
    val spots: List<PointF>,
    val startGold: Int,
    val lives: Int,
    val waves: Int,
    val hpMult: Float
) {
    fun distToPath(px: Float, py: Float): Float {
        var best = Float.MAX_VALUE
        for (i in 0 until path.size - 1) {
            val a = path[i]
            val b = path[i + 1]
            val abx = b.x - a.x
            val aby = b.y - a.y
            val len2 = abx * abx + aby * aby
            var t = if (len2 == 0f) 0f else ((px - a.x) * abx + (py - a.y) * aby) / len2
            t = t.coerceIn(0f, 1f)
            best = min(best, hypot(px - (a.x + abx * t), py - (a.y + aby * t)))
        }
        return best
    }
}

class SpawnEntry(val type: EnemyType, val at: Float, val hpScale: Float)

object Levels {
    private fun p(x: Int, y: Int) = PointF(x.toFloat(), y.toFloat())

    val all: List<LevelDef> = listOf(
        // 1 — ثعبان
        LevelDef(
            1,
            listOf(p(-30, 150), p(300, 150), p(300, 360), p(640, 360), p(640, 560), p(980, 560), p(980, 250), p(1230, 250)),
            listOf(
                p(150, 240), p(420, 250), p(540, 270), p(210, 450), p(480, 470), p(770, 450),
                p(770, 660), p(880, 440), p(880, 250), p(1100, 350), p(1100, 150)
            ),
            220, 20, 8, 1.0f
        ),
        // 2 — حرف U
        LevelDef(
            2,
            listOf(p(-30, 600), p(200, 600), p(200, 120), p(560, 120), p(560, 520), p(900, 520), p(900, 160), p(1230, 160)),
            listOf(
                p(110, 300), p(110, 450), p(310, 420), p(310, 230), p(430, 230), p(460, 340),
                p(660, 300), p(730, 420), p(730, 620), p(800, 300), p(1010, 330), p(1100, 260)
            ),
            240, 20, 10, 1.1f
        ),
        // 3 — متعرّج
        LevelDef(
            3,
            listOf(p(-30, 120), p(1000, 120), p(1000, 300), p(280, 300), p(280, 480), p(1000, 480), p(1000, 640), p(1230, 640)),
            listOf(
                p(400, 210), p(600, 210), p(800, 210), p(1110, 210), p(190, 390), p(420, 390),
                p(620, 390), p(820, 390), p(440, 570), p(640, 570), p(840, 570), p(1110, 540)
            ),
            260, 20, 12, 1.2f
        ),
        // 4 — حلزون
        LevelDef(
            4,
            listOf(
                p(-30, 360), p(160, 360), p(160, 100), p(1120, 100), p(1120, 620),
                p(320, 620), p(320, 260), p(900, 260), p(900, 440), p(640, 440)
            ),
            listOf(
                p(250, 200), p(500, 180), p(700, 180), p(900, 180), p(1030, 190), p(1020, 360), p(780, 350),
                p(620, 350), p(420, 360), p(230, 470), p(80, 470), p(420, 540), p(600, 540), p(800, 540), p(1020, 540)
            ),
            280, 20, 14, 1.3f
        ),
        // 5 — حرف W
        LevelDef(
            5,
            listOf(
                p(-30, 600), p(240, 600), p(240, 200), p(480, 200), p(480, 600),
                p(720, 600), p(720, 200), p(960, 200), p(960, 600), p(1230, 600)
            ),
            listOf(
                p(130, 300), p(130, 500), p(360, 110), p(360, 300), p(360, 500), p(600, 300), p(600, 500),
                p(600, 690), p(840, 110), p(840, 300), p(840, 500), p(1060, 350), p(1110, 500)
            ),
            300, 20, 16, 1.4f
        )
    )

    /** يولّد قائمة ظهور الأعداء للموجة n (تبدأ من 1). */
    fun wave(n: Int, lv: LevelDef, clock: Float): List<SpawnEntry> {
        val scale = (1f + 0.08f * (n - 1)) * lv.hpMult
        val out = ArrayList<SpawnEntry>()
        var t = clock + 0.5f
        fun add(type: EnemyType, count: Int, gap: Float) {
            repeat(count) {
                out.add(SpawnEntry(type, t, scale))
                t += gap
            }
            t += 1.2f
        }
        add(EnemyType.GRUNT, 5 + n * 2, max(0.45f, 1.1f - n * 0.04f))
        if (n >= 3) add(EnemyType.RUNNER, 2 + n, 0.55f)
        if (n >= 4 && n % 2 == 0) add(EnemyType.FLYER, 1 + n / 2, 0.9f)
        if (n >= 5) add(EnemyType.TANK, 1 + n / 3, 2.4f)
        if (n == lv.waves) add(EnemyType.BOSS, 1 + lv.waves / 12, 5f)
        return out
    }
}
