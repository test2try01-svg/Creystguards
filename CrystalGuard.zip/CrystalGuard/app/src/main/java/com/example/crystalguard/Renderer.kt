package com.example.crystalguard

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** كل الرسم يتم برمجيًا بالـ Canvas — لا توجد أي صور أو ملفات خارجية. */
class Renderer(private val g: Game) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val tmp = Path()
    private val rf = RectF()

    private var bg: Bitmap? = null
    private var bgLevel = -1

    private val menuShader = LinearGradient(
        0f, 0f, 0f, Game.H, 0xFF16324A.toInt(), 0xFF3E7A41.toInt(), Shader.TileMode.CLAMP
    )

    private val white = Color.WHITE
    private val gold = 0xFFFFD54F.toInt()

    // ───────────────────────── نقطة الدخول ─────────────────────────

    fun draw(c: Canvas, scale: Float, offX: Float, offY: Float) {
        c.drawColor(Color.BLACK)
        c.save()
        c.translate(offX, offY)
        c.scale(scale, scale)
        c.clipRect(0f, 0f, Game.W, Game.H)
        if (g.state == Game.State.MENU) {
            drawMenu(c)
        } else {
            drawWorld(c)
            drawHud(c)
            drawPanel(c)
            drawOverlay(c)
        }
        c.restore()
    }

    // ───────────────────────── أدوات مساعدة ─────────────────────────

    private fun label(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        align: Paint.Align = Paint.Align.CENTER, shadow: Boolean = false
    ) {
        text.textSize = size
        text.textAlign = align
        if (shadow) {
            text.color = 0x99000000.toInt()
            c.drawText(s, x + 2f, y + size * 0.35f + 2f, text)
        }
        text.color = color
        c.drawText(s, x, y + size * 0.35f, text)
    }

    private fun rrect(c: Canvas, r: RectF, color: Int, rad: Float = 14f) {
        fill.color = color
        c.drawRoundRect(r, rad, rad, fill)
    }

    private fun alpha(color: Int, a: Float): Int {
        val al = (255f * a.coerceIn(0f, 1f)).toInt()
        return (al shl 24) or (color and 0xFFFFFF)
    }

    private fun deg(a: Float) = a * 57.29578f

    private fun star(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        tmp.reset()
        for (i in 0 until 10) {
            val rad = if (i % 2 == 0) r else r * 0.45f
            val a = (-Math.PI / 2 + i * Math.PI / 5).toFloat()
            val px = cx + cos(a) * rad
            val py = cy + sin(a) * rad
            if (i == 0) tmp.moveTo(px, py) else tmp.lineTo(px, py)
        }
        tmp.close()
        fill.color = color
        c.drawPath(tmp, fill)
    }

    private fun heart(c: Canvas, x: Float, y: Float, s: Float, color: Int) {
        tmp.reset()
        tmp.moveTo(x, y + 10f * s)
        tmp.cubicTo(x - 18f * s, y - 2f * s, x - 10f * s, y - 16f * s, x, y - 6f * s)
        tmp.cubicTo(x + 10f * s, y - 16f * s, x + 18f * s, y - 2f * s, x, y + 10f * s)
        tmp.close()
        fill.color = color
        c.drawPath(tmp, fill)
    }

    // ───────────────────────── القائمة ─────────────────────────

    private fun drawMenu(c: Canvas) {
        fill.shader = menuShader
        c.drawRect(0f, 0f, Game.W, Game.H, fill)
        fill.shader = null

        label(c, T.title, 640f, 110f, 84f, white, shadow = true)
        label(c, T.choose, 640f, 195f, 32f, 0xFFB2EBF2.toInt())

        for (i in Levels.all.indices) {
            val r = g.levelRect(i)
            val un = g.isUnlocked(i)
            rrect(c, r, if (un) 0xFF2E6F73.toInt() else 0xFF3B4247.toInt(), 22f)
            stroke.color = if (un) 0xFF7FD6D1.toInt() else 0xFF566068.toInt()
            stroke.strokeWidth = 4f
            c.drawRoundRect(r, 22f, 22f, stroke)
            if (un) {
                label(c, "${i + 1}", r.centerX(), r.top + 72f, 88f, white, shadow = true)
                val st = g.starsOf(i)
                for (k in 0 until 3) {
                    star(c, r.centerX() + (k - 1) * 50f, r.bottom - 42f, 20f, if (k < st) gold else 0xFF4A5A60.toInt())
                }
            } else {
                val cx = r.centerX()
                val cy = r.centerY()
                rrect(c, RectF(cx - 24f, cy - 6f, cx + 24f, cy + 32f), 0xFF90A4AE.toInt(), 6f)
                stroke.color = 0xFFB0BEC5.toInt()
                stroke.strokeWidth = 7f
                c.drawArc(RectF(cx - 15f, cy - 34f, cx + 15f, cy + 4f), 180f, 180f, false, stroke)
            }
        }
        drawCrystal(c, 640f, 570f, 60f)
    }

    private fun drawCrystal(c: Canvas, x: Float, y0: Float, s: Float) {
        val y = y0 + sin(g.time * 2f) * 4f
        val pulse = 0.6f + 0.4f * sin(g.time * 3f)
        fill.color = alpha(0xFF4DD0E1.toInt(), 0.10f * pulse)
        c.drawCircle(x, y, s * 1.9f, fill)
        fill.color = alpha(0xFF4DD0E1.toInt(), 0.16f * pulse)
        c.drawCircle(x, y, s * 1.3f, fill)
        // الحجر تحتها
        fill.color = 0x55000000
        c.drawOval(x - s * 0.8f, y + s * 0.75f, x + s * 0.8f, y + s * 1.05f, fill)
        // الجسم
        tmp.reset()
        tmp.moveTo(x, y - s); tmp.lineTo(x + s * 0.6f, y - s * 0.1f)
        tmp.lineTo(x, y + s * 0.85f); tmp.lineTo(x - s * 0.6f, y - s * 0.1f); tmp.close()
        fill.color = 0xFF4DD0E1.toInt()
        c.drawPath(tmp, fill)
        tmp.reset()
        tmp.moveTo(x, y - s); tmp.lineTo(x - s * 0.6f, y - s * 0.1f); tmp.lineTo(x, y + s * 0.85f); tmp.close()
        fill.color = 0xFFB2EBF2.toInt()
        c.drawPath(tmp, fill)
        tmp.reset()
        tmp.moveTo(x, y - s); tmp.lineTo(x + s * 0.2f, y - s * 0.15f); tmp.lineTo(x, y - s * 0.3f); tmp.close()
        fill.color = 0xAAFFFFFF.toInt()
        c.drawPath(tmp, fill)
    }

    // ───────────────────────── العالم ─────────────────────────

    private fun drawWorld(c: Canvas) {
        if (bgLevel != g.levelIdx || bg == null) {
            bg?.recycle()
            bg = buildBg(g.level)
            bgLevel = g.levelIdx
        }
        c.drawBitmap(bg!!, 0f, 0f, null)

        val lv = g.level
        // تمييز المنصة المختارة
        if (g.selSpot >= 0) {
            val s = lv.spots[g.selSpot]
            stroke.color = white; stroke.strokeWidth = 4f
            c.drawCircle(s.x, s.y, 40f + sin(g.time * 8f) * 2f, stroke)
        }
        g.selTower?.let { t ->
            fill.color = 0x30FFFFFF
            c.drawCircle(t.x, t.y, t.stats.range, fill)
            stroke.color = 0xAAFFFFFF.toInt(); stroke.strokeWidth = 3f
            c.drawCircle(t.x, t.y, t.stats.range, stroke)
        }

        // البلورة (الهدف) وعلامة الظهور
        val end = lv.path.last()
        drawCrystal(c, end.x, end.y - 8f, 26f)
        val st = lv.path[0]
        val ax = 26f + sin(g.time * 5f) * 5f
        tmp.reset()
        tmp.moveTo(ax + 16f, st.y); tmp.lineTo(ax - 4f, st.y - 18f); tmp.lineTo(ax - 4f, st.y + 18f); tmp.close()
        fill.color = 0xCCE53935.toInt()
        c.drawPath(tmp, fill)

        for (e in g.enemies) if (!e.type.flying) drawEnemy(c, e)
        for (t in g.towers) drawTowerShape(c, t.type, t.level, t.angle, t.x, t.y)
        for (e in g.enemies) if (e.type.flying) drawEnemy(c, e)

        for (p in g.projectiles) drawProjectile(c, p)

        for (b in g.bolts) {
            val a = (b.life / 0.18f).coerceIn(0f, 1f)
            tmp.reset()
            tmp.moveTo(b.xs[0], b.ys[0])
            for (i in 1 until b.xs.size) tmp.lineTo(b.xs[i], b.ys[i])
            stroke.color = alpha(0xFFCE93D8.toInt(), a * 0.6f); stroke.strokeWidth = 10f
            c.drawPath(tmp, stroke)
            stroke.color = alpha(white, a); stroke.strokeWidth = 3f
            c.drawPath(tmp, stroke)
        }

        for (p in g.particles) {
            fill.color = alpha(p.color, p.life / p.maxLife)
            c.drawCircle(p.x, p.y, p.size * (0.5f + p.life / p.maxLife), fill)
        }
        for (f in g.texts) label(c, f.text, f.x, f.y, 24f, alpha(f.color, f.life / 0.9f), shadow = true)
    }

    private fun drawProjectile(c: Canvas, p: Projectile) {
        when (p.kind) {
            TowerType.ARCHER -> {
                val a = atan2(p.ty - p.y, p.tx - p.x)
                val dx = cos(a) * 14f
                val dy = sin(a) * 14f
                stroke.color = 0xFF5D4037.toInt(); stroke.strokeWidth = 3f
                c.drawLine(p.x - dx, p.y - dy, p.x + dx, p.y + dy, stroke)
                fill.color = 0xFFECEFF1.toInt()
                c.drawCircle(p.x + dx, p.y + dy, 3f, fill)
            }
            TowerType.CANNON -> {
                fill.color = 0xFF212121.toInt(); c.drawCircle(p.x, p.y, 8f, fill)
                fill.color = 0xFF616161.toInt(); c.drawCircle(p.x - 2f, p.y - 2f, 3f, fill)
            }
            else -> {
                fill.color = 0x6681D4FA; c.drawCircle(p.x, p.y, 10f, fill)
                fill.color = 0xFFE1F5FE.toInt(); c.drawCircle(p.x, p.y, 5f, fill)
            }
        }
    }

    // ───────────────────────── الأعداء ─────────────────────────

    private fun drawEnemy(c: Canvas, e: Enemy) {
        val r = e.type.radius
        val hover = if (e.type.flying) 18f + sin(g.time * 6f + e.x * 0.05f) * 3f else 0f
        val by = e.y - hover

        // الظل
        fill.color = 0x44000000
        c.drawOval(e.x - r, e.y + r * 0.45f - 4f, e.x + r, e.y + r * 0.45f + 6f, fill)

        when (e.type) {
            EnemyType.FLYER -> {
                val flap = 6f + abs(sin(g.time * 18f + e.x)) * 12f
                fill.color = 0xFFFFCDD2.toInt()
                c.drawOval(e.x - r - 14f, by - flap, e.x - r + 6f, by + 4f, fill)
                c.drawOval(e.x + r - 6f, by - flap, e.x + r + 14f, by + 4f, fill)
            }
            EnemyType.BOSS -> {
                tmp.reset()
                tmp.moveTo(e.x - r * 0.7f, by - r * 0.5f); tmp.lineTo(e.x - r * 1.0f, by - r * 1.5f); tmp.lineTo(e.x - r * 0.2f, by - r * 0.9f); tmp.close()
                tmp.moveTo(e.x + r * 0.7f, by - r * 0.5f); tmp.lineTo(e.x + r * 1.0f, by - r * 1.5f); tmp.lineTo(e.x + r * 0.2f, by - r * 0.9f); tmp.close()
                fill.color = 0xFFFFC107.toInt()
                c.drawPath(tmp, fill)
            }
            else -> {}
        }

        fill.color = e.type.color
        if (e.type == EnemyType.RUNNER) {
            c.drawOval(e.x - r * 1.15f, by - r * 0.85f, e.x + r * 1.15f, by + r * 0.85f, fill)
        } else {
            c.drawCircle(e.x, by, r, fill)
        }
        if (e.type == EnemyType.TANK) {
            rf.set(e.x - r, by - r, e.x + r, by + r)
            fill.color = 0xFF90A4AE.toInt()
            c.drawArc(rf, 180f, 180f, true, fill)
        }

        // العينان
        fill.color = white
        c.drawCircle(e.x - r * 0.35f, by - r * 0.1f, r * 0.26f, fill)
        c.drawCircle(e.x + r * 0.35f, by - r * 0.1f, r * 0.26f, fill)
        fill.color = Color.BLACK
        c.drawCircle(e.x - r * 0.3f, by - r * 0.05f, r * 0.12f, fill)
        c.drawCircle(e.x + r * 0.4f, by - r * 0.05f, r * 0.12f, fill)

        if (e.flash > 0f) {
            fill.color = 0x88FFFFFF.toInt()
            c.drawCircle(e.x, by, r, fill)
        }
        if (e.slowT > 0f) {
            stroke.color = 0xFF81D4FA.toInt(); stroke.strokeWidth = 3f
            c.drawCircle(e.x, by, r + 3f, stroke)
        }
        if (e.hp < e.maxHp) {
            val w = r * 2f + 6f
            val bx = e.x - w / 2f
            val ty = by - r - 12f
            fill.color = 0xAA000000.toInt()
            c.drawRect(bx, ty, bx + w, ty + 5f, fill)
            val frac = (e.hp / e.maxHp).coerceIn(0f, 1f)
            fill.color = if (frac > 0.5f) 0xFF66BB6A.toInt() else if (frac > 0.25f) 0xFFFFCA28.toInt() else 0xFFEF5350.toInt()
            c.drawRect(bx, ty, bx + w * frac, ty + 5f, fill)
        }
    }

    // ───────────────────────── الأبراج ─────────────────────────

    private fun drawTowerShape(c: Canvas, type: TowerType, level: Int, angle: Float, x: Float, y: Float) {
        fill.color = 0x55000000
        c.drawOval(x - 30f, y + 14f, x + 30f, y + 32f, fill)
        fill.color = 0xFF6D6D6D.toInt()
        c.drawCircle(x, y + 4f, 27f, fill)
        if (level >= 1) {
            stroke.color = if (level == 1) 0xFFCFD8DC.toInt() else 0xFFFFC107.toInt()
            stroke.strokeWidth = 4f
            c.drawCircle(x, y + 4f, 27f, stroke)
        }

        when (type) {
            TowerType.ARCHER -> {
                fill.color = 0xFF8D6E4A.toInt()
                c.drawRoundRect(x - 16f, y - 14f, x + 16f, y + 14f, 4f, 4f, fill)
                fill.color = 0xFF6D4C2F.toInt()
                c.drawRect(x - 16f, y - 20f, x - 8f, y - 12f, fill)
                c.drawRect(x - 4f, y - 20f, x + 4f, y - 12f, fill)
                c.drawRect(x + 8f, y - 20f, x + 16f, y - 12f, fill)
                fill.color = 0xFFFFCC80.toInt()
                c.drawCircle(x, y - 24f, 7f, fill)
                rf.set(x - 7f, y - 31f, x + 7f, y - 17f)
                fill.color = 0xFF2E7D32.toInt()
                c.drawArc(rf, 180f, 180f, true, fill)
                c.save()
                c.translate(x, y - 18f)
                c.rotate(deg(angle))
                stroke.color = 0xFF4E342E.toInt(); stroke.strokeWidth = 3f
                rf.set(2f, -13f, 20f, 13f)
                c.drawArc(rf, -90f, 180f, false, stroke)
                stroke.strokeWidth = 1.5f; stroke.color = white
                c.drawLine(11f, -13f, 11f, 13f, stroke)
                c.restore()
            }
            TowerType.CANNON -> {
                fill.color = 0xFF455A64.toInt()
                c.drawCircle(x, y - 4f, 20f, fill)
                c.save()
                c.translate(x, y - 4f)
                c.rotate(deg(angle))
                fill.color = 0xFF263238.toInt()
                c.drawRoundRect(0f, -7f, 34f, 7f, 3f, 3f, fill)
                fill.color = 0xFF37474F.toInt()
                c.drawRect(28f, -9f, 36f, 9f, fill)
                c.restore()
                fill.color = 0xFF607D8B.toInt()
                c.drawCircle(x, y - 4f, 9f, fill)
            }
            TowerType.FROST -> {
                val pulse = 0.5f + 0.5f * sin(g.time * 4f)
                fill.color = alpha(0xFF81D4FA.toInt(), 0.18f + 0.12f * pulse)
                c.drawCircle(x, y - 16f, 26f, fill)
                fill.color = 0xFF78909C.toInt()
                c.drawRoundRect(x - 14f, y + 2f, x + 14f, y + 14f, 4f, 4f, fill)
                tmp.reset()
                tmp.moveTo(x, y - 38f); tmp.lineTo(x + 14f, y - 15f); tmp.lineTo(x, y + 4f); tmp.lineTo(x - 14f, y - 15f); tmp.close()
                fill.color = 0xFF4FC3F7.toInt()
                c.drawPath(tmp, fill)
                tmp.reset()
                tmp.moveTo(x, y - 38f); tmp.lineTo(x - 14f, y - 15f); tmp.lineTo(x, y + 4f); tmp.close()
                fill.color = 0xFF81D4FA.toInt()
                c.drawPath(tmp, fill)
                stroke.color = 0xAAFFFFFF.toInt(); stroke.strokeWidth = 2f
                c.drawLine(x + 4f, y - 28f, x + 8f, y - 18f, stroke)
            }
            TowerType.MAGE -> {
                tmp.reset()
                tmp.moveTo(x - 10f, y - 6f); tmp.lineTo(x + 10f, y - 6f); tmp.lineTo(x + 15f, y + 14f); tmp.lineTo(x - 15f, y + 14f); tmp.close()
                fill.color = 0xFF5E35B1.toInt()
                c.drawPath(tmp, fill)
                fill.color = 0xFF7E57C2.toInt()
                c.drawRect(x - 12f, y + 2f, x + 12f, y + 5f, fill)
                val pulse = 0.5f + 0.5f * sin(g.time * 4f)
                fill.color = alpha(0xFFCE93D8.toInt(), 0.20f + 0.15f * pulse)
                c.drawCircle(x, y - 20f, 22f, fill)
                fill.color = 0xFFBA68C8.toInt()
                c.drawCircle(x, y - 20f, 12f + pulse * 1.5f, fill)
                fill.color = 0xFFF3E5F5.toInt()
                c.drawCircle(x - 3f, y - 23f, 4f, fill)
            }
        }
        for (i in 0..level) {
            fill.color = gold
            c.drawCircle(x - level * 6f + i * 12f, y + 27f, 3.5f, fill)
        }
    }

    // ───────────────────────── الواجهة ─────────────────────────

    private fun drawHud(c: Canvas) {
        fill.color = 0x99000000.toInt()
        c.drawRect(0f, 0f, Game.W, 56f, fill)

        heart(c, 30f, 30f, 1.2f, 0xFFE53935.toInt())
        label(c, "${g.lives}", 56f, 28f, 30f, white, Paint.Align.LEFT)

        fill.color = gold
        c.drawCircle(170f, 28f, 13f, fill)
        fill.color = 0xFFFFA000.toInt()
        c.drawCircle(170f, 28f, 8f, fill)
        label(c, "${g.gold}", 192f, 28f, 30f, gold, Paint.Align.LEFT)

        label(c, T.wave(g.waveNum, g.level.waves), 640f, 28f, 30f, white)

        rrect(c, g.speedBtn, if (g.speed == 2) 0xFFFFB300.toInt() else 0x55FFFFFF, 10f)
        label(c, "x${g.speed}", g.speedBtn.centerX(), g.speedBtn.centerY(), 26f, white)
        rrect(c, g.pauseBtn, 0x55FFFFFF, 10f)
        fill.color = white
        c.drawRect(g.pauseBtn.centerX() - 11f, g.pauseBtn.centerY() - 11f, g.pauseBtn.centerX() - 3f, g.pauseBtn.centerY() + 11f, fill)
        c.drawRect(g.pauseBtn.centerX() + 3f, g.pauseBtn.centerY() - 11f, g.pauseBtn.centerX() + 11f, g.pauseBtn.centerY() + 11f, fill)

        if (g.waveNum < g.level.waves) {
            val b = g.nextBtn
            rrect(c, b, 0xFF43A047.toInt(), 16f)
            label(c, T.nextWave, b.centerX(), b.centerY() - 5f, 24f, white)
            if (!g.spawning()) {
                val frac = (g.countdown / 18f).coerceIn(0f, 1f)
                fill.color = 0x66000000
                c.drawRect(b.left + 14f, b.bottom - 11f, b.right - 14f, b.bottom - 6f, fill)
                fill.color = 0xFFC8E6C9.toInt()
                c.drawRect(b.left + 14f, b.bottom - 11f, b.left + 14f + (b.width() - 28f) * frac, b.bottom - 6f, fill)
                label(c, "+${(g.countdown / 2f).toInt()}", b.left + 28f, b.top - 12f, 22f, gold, shadow = true)
            }
        }
        if (g.waveNum == 0 && !g.panelVisible() && g.state == Game.State.PLAYING) {
            label(c, T.hint, 640f, 696f, 22f, 0xCCFFFFFF.toInt(), shadow = true)
        }
    }

    private fun drawPanel(c: Canvas) {
        if (!g.panelVisible()) return
        val p = g.panelRect()
        rrect(c, p, 0xE61E272E.toInt(), 18f)
        stroke.color = 0xFF607D8B.toInt(); stroke.strokeWidth = 3f
        c.drawRoundRect(p, 18f, 18f, stroke)

        if (g.selSpot >= 0) {
            val types = TowerType.values()
            for (i in types.indices) {
                val b = g.buildBtn(i)
                val t = types[i]
                val cost = t.levels[0].cost
                val ok = g.gold >= cost
                rrect(c, b, if (ok) 0xFF37474F.toInt() else 0xFF2A2F33.toInt(), 14f)
                c.save()
                c.translate(b.centerX(), b.top + 38f)
                c.scale(0.62f, 0.62f)
                drawTowerShape(c, t, 0, -1.5708f, 0f, 0f)
                c.restore()
                label(c, T.tower(t), b.centerX(), b.bottom - 28f, 19f, white)
                label(c, "$cost", b.centerX(), b.bottom - 9f, 19f, if (ok) gold else 0xFFEF5350.toInt())
            }
        } else {
            val t = g.selTower ?: return
            val s = t.stats
            label(c, "${T.tower(t.type)}  ${T.lv(t.level + 1)}", p.left + 18f, p.top + 34f, 24f, white, Paint.Align.LEFT)
            label(c, "${T.dmg} ${s.damage.toInt()}   ${T.rng} ${s.range.toInt()}", p.left + 18f, p.top + 68f, 19f, 0xFFB0BEC5.toInt(), Paint.Align.LEFT)

            val ub = g.upgradeBtn()
            if (t.canUpgrade()) {
                val cost = t.upgradeCost()
                val ok = g.gold >= cost
                rrect(c, ub, if (ok) 0xFF2E7D32.toInt() else 0xFF2A2F33.toInt(), 14f)
                label(c, T.upgrade, ub.centerX(), ub.centerY() - 14f, 24f, white)
                label(c, "$cost", ub.centerX(), ub.centerY() + 16f, 22f, if (ok) gold else 0xFFEF5350.toInt())
            } else {
                rrect(c, ub, 0xFF2A2F33.toInt(), 14f)
                label(c, T.maxed, ub.centerX(), ub.centerY(), 24f, gold)
            }
            val sb = g.sellBtn()
            rrect(c, sb, 0xFFEF6C00.toInt(), 14f)
            label(c, T.sell, sb.centerX(), sb.centerY() - 14f, 24f, white)
            label(c, "+${t.sellValue()}", sb.centerX(), sb.centerY() + 16f, 22f, white)
        }
    }

    private fun drawOverlay(c: Canvas) {
        when (g.state) {
            Game.State.PAUSED -> {
                dim(c)
                rrect(c, g.pauseCard, 0xFF263238.toInt(), 26f)
                label(c, T.paused, 640f, 242f, 46f, white, shadow = true)
                button(c, g.pauseResume, T.resume, 0xFF43A047.toInt())
                button(c, g.pauseRestart, T.restart, 0xFF1E88E5.toInt())
                button(c, g.pauseMenu, T.menu, 0xFF546E7A.toInt())
            }
            Game.State.WON, Game.State.LOST -> {
                dim(c)
                val won = g.state == Game.State.WON
                rrect(c, g.endCard, 0xFF263238.toInt(), 26f)
                label(c, if (won) T.victory else T.defeat, 640f, 190f, 60f, if (won) gold else 0xFFEF5350.toInt(), shadow = true)
                if (won) {
                    for (k in 0 until 3) {
                        star(c, 640f + (k - 1) * 100f, 300f + (if (k == 1) -14f else 0f), 44f, if (k < g.stars) gold else 0xFF4A5A60.toInt())
                    }
                }
                val first = if (won) T.nextLevel else T.retry
                button(c, g.endBtn1, first, if (won) 0xFF43A047.toInt() else 0xFF1E88E5.toInt())
                button(c, g.endBtn2, T.menu, 0xFF546E7A.toInt())
            }
            else -> {}
        }
    }

    private fun dim(c: Canvas) {
        fill.color = 0xAA000000.toInt()
        c.drawRect(0f, 0f, Game.W, Game.H, fill)
    }

    private fun button(c: Canvas, r: RectF, s: String, color: Int) {
        rrect(c, r, color, 18f)
        label(c, s, r.centerX(), r.centerY(), 30f, white)
    }

    // ───────────────────────── الخلفية (تُرسم مرة واحدة لكل مرحلة) ─────────────────────────

    private fun buildBg(lv: LevelDef): Bitmap {
        val bmp = Bitmap.createBitmap(Game.W.toInt(), Game.H.toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, Game.H, 0xFF5FA35A.toInt(), 0xFF3F7F43.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, Game.W, Game.H, p)
        p.shader = null

        val rnd = java.util.Random(1000L + lv.seed)

        // عشب وزهور
        repeat(340) {
            val x = rnd.nextFloat() * Game.W
            val y = rnd.nextFloat() * Game.H
            if (lv.distToPath(x, y) < 50f) return@repeat
            p.color = if (rnd.nextBoolean()) 0x22000000 else 0x26FFFFFF
            val w = 6f + rnd.nextFloat() * 10f
            c.drawOval(x - w, y - w * 0.5f, x + w, y + w * 0.5f, p)
        }
        val flowers = intArrayOf(0xFFFFEB3B.toInt(), 0xFFFFFFFF.toInt(), 0xFFF48FB1.toInt(), 0xFF90CAF9.toInt())
        repeat(70) {
            val x = rnd.nextFloat() * Game.W
            val y = 60f + rnd.nextFloat() * (Game.H - 60f)
            if (lv.distToPath(x, y) < 48f) return@repeat
            p.color = flowers[rnd.nextInt(flowers.size)]
            c.drawCircle(x, y, 3f, p)
        }

        // المسار
        val path = Path()
        path.moveTo(lv.path[0].x, lv.path[0].y)
        for (i in 1 until lv.path.size) path.lineTo(lv.path[i].x, lv.path[i].y)
        val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
        sp.color = 0xFF7A5C2E.toInt(); sp.strokeWidth = 76f; c.drawPath(path, sp)
        sp.color = 0xFFD9BF86.toInt(); sp.strokeWidth = 64f; c.drawPath(path, sp)
        sp.color = 0x33FFFFFF; sp.strokeWidth = 4f
        sp.pathEffect = DashPathEffect(floatArrayOf(14f, 18f), 0f)
        c.drawPath(path, sp)
        sp.pathEffect = null

        // منصات البناء
        for (s in lv.spots) {
            p.color = 0x44000000
            c.drawOval(s.x - 36f, s.y + 14f, s.x + 36f, s.y + 38f, p)
            p.color = 0xFF8E8E8E.toInt(); c.drawCircle(s.x, s.y, 36f, p)
            p.color = 0xFFB4B4B4.toInt(); c.drawCircle(s.x, s.y, 30f, p)
            sp.color = 0xFF6B6B6B.toInt(); sp.strokeWidth = 3f
            c.drawCircle(s.x, s.y, 36f, sp)
        }

        // أشجار وصخور بعيدًا عن المسار والمنصات
        var trees = 0
        var tries = 0
        while (trees < 16 && tries < 600) {
            tries++
            val x = 30f + rnd.nextFloat() * (Game.W - 60f)
            val y = 90f + rnd.nextFloat() * (Game.H - 120f)
            if (lv.distToPath(x, y) < 85f) continue
            var near = false
            for (s in lv.spots) if (kotlin.math.hypot(x - s.x, y - s.y) < 75f) { near = true; break }
            if (near) continue
            p.color = 0x33000000
            c.drawOval(x - 26f, y + 14f, x + 26f, y + 30f, p)
            p.color = 0xFF5D4037.toInt(); c.drawRect(x - 4f, y, x + 4f, y + 22f, p)
            p.color = 0xFF2E7D32.toInt(); c.drawCircle(x, y - 8f, 24f, p)
            p.color = 0xFF388E3C.toInt(); c.drawCircle(x - 9f, y - 2f, 17f, p)
            p.color = 0xFF43A047.toInt(); c.drawCircle(x + 8f, y - 16f, 14f, p)
            trees++
        }
        var rocks = 0
        tries = 0
        while (rocks < 10 && tries < 400) {
            tries++
            val x = 30f + rnd.nextFloat() * (Game.W - 60f)
            val y = 90f + rnd.nextFloat() * (Game.H - 120f)
            if (lv.distToPath(x, y) < 70f) continue
            var near = false
            for (s in lv.spots) if (kotlin.math.hypot(x - s.x, y - s.y) < 65f) { near = true; break }
            if (near) continue
            p.color = 0xFF78909C.toInt(); c.drawOval(x - 14f, y - 9f, x + 14f, y + 9f, p)
            p.color = 0xFF90A4AE.toInt(); c.drawOval(x - 9f, y - 8f, x + 6f, y + 2f, p)
            rocks++
        }
        return bmp
    }
}
