package com.example.crystalguard

import android.content.Context
import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

// ───────────────────────── الكيانات ─────────────────────────

class Enemy(val type: EnemyType, val maxHp: Float, start: PointF) {
    var hp = maxHp
    var x = start.x
    var y = start.y
    var seg = 0
    var dist = 0f
    var slowT = 0f
    var slowAmt = 0f
    var flash = 0f
    var alive = true
    var reached = false

    fun slow(amt: Float, dur: Float) {
        if (slowT <= 0f || amt > slowAmt) slowAmt = amt
        slowT = max(slowT, dur)
    }

    fun update(dt: Float, path: List<PointF>) {
        if (slowT > 0f) {
            slowT -= dt
            if (slowT <= 0f) slowAmt = 0f
        }
        if (flash > 0f) flash -= dt
        val sp = type.speed * (1f - slowAmt) * dt
        if (type.flying) {
            // الطيور تطير بخط مستقيم نحو البلورة وتتجاهل المسار
            val end = path.last()
            val dx = end.x - x
            val dy = end.y - y
            val d = hypot(dx, dy)
            if (d <= sp) {
                reached = true
                return
            }
            x += dx / d * sp
            y += dy / d * sp
            dist += sp
        } else {
            var move = sp
            while (move > 0f) {
                if (seg >= path.size - 1) {
                    reached = true
                    return
                }
                val tg = path[seg + 1]
                val dx = tg.x - x
                val dy = tg.y - y
                val d = hypot(dx, dy)
                if (d <= move) {
                    x = tg.x
                    y = tg.y
                    seg++
                    move -= d
                    dist += d
                } else {
                    x += dx / d * move
                    y += dy / d * move
                    dist += move
                    move = 0f
                }
            }
        }
    }
}

class Tower(val type: TowerType, val x: Float, val y: Float, val spot: Int) {
    var level = 0
    var cd = 0.3f
    var angle = -1.5708f
    var invested = type.levels[0].cost
    val stats: TowerStats get() = type.levels[level]
    fun canUpgrade() = level < type.levels.size - 1
    fun upgradeCost() = type.levels[level + 1].cost
    fun sellValue() = (invested * 0.7f).toInt()
}

class Projectile(
    var x: Float, var y: Float, val target: Enemy?, val damage: Float,
    val splash: Float, val slow: Float, val speed: Float, val kind: TowerType
) {
    var tx = target?.x ?: x
    var ty = target?.y ?: y
    var dead = false
}

class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    var life: Float, val maxLife: Float, val color: Int, val size: Float
)

class Bolt(val xs: FloatArray, val ys: FloatArray, var life: Float)

class FloatText(var x: Float, var y: Float, val text: String, var life: Float, val color: Int)

// ───────────────────────── منطق اللعبة ─────────────────────────

class Game(context: Context) {
    companion object {
        const val W = 1280f
        const val H = 720f
    }

    enum class State { MENU, PLAYING, PAUSED, WON, LOST }

    private val prefs = context.getSharedPreferences("crystal_guard", Context.MODE_PRIVATE)
    private val rnd = java.util.Random()

    var state = State.MENU
    var levelIdx = 0
    var level: LevelDef = Levels.all[0]
    var gold = 0
    var lives = 0
    var waveNum = 0
    var speed = 1
    var countdown = 0f
    var time = 0f
    var stars = 0
    private var clock = 0f

    val enemies = ArrayList<Enemy>()
    val towers = ArrayList<Tower>()
    val projectiles = ArrayList<Projectile>()
    val particles = ArrayList<Particle>()
    val bolts = ArrayList<Bolt>()
    val texts = ArrayList<FloatText>()
    private val pending = ArrayList<SpawnEntry>()

    var spotTower: Array<Tower?> = arrayOfNulls(0)
    var selSpot = -1
    var selTower: Tower? = null

    // ───── مستطيلات الواجهة (بإحداثيات العالم 1280×720) ─────
    val pauseBtn = RectF(1210f, 6f, 1270f, 50f)
    val speedBtn = RectF(1140f, 6f, 1200f, 50f)
    val nextBtn = RectF(1070f, 644f, 1264f, 706f)
    val pauseCard = RectF(440f, 200f, 840f, 580f)
    val pauseResume = RectF(490f, 280f, 790f, 350f)
    val pauseRestart = RectF(490f, 370f, 790f, 440f)
    val pauseMenu = RectF(490f, 460f, 790f, 530f)
    val endCard = RectF(390f, 120f, 890f, 620f)
    val endBtn1 = RectF(490f, 430f, 790f, 500f)
    val endBtn2 = RectF(490f, 520f, 790f, 590f)

    fun levelRect(i: Int) = RectF(105f + i * 220f, 260f, 295f + i * 220f, 450f)

    fun panelVisible() = state == State.PLAYING && (selSpot >= 0 || selTower != null)

    fun panelRect(): RectF {
        val sy = if (selSpot >= 0) level.spots[selSpot].y else (selTower?.y ?: 0f)
        val top = if (sy > 380f) 66f else 586f
        return RectF(296f, top, 984f, top + 118f)
    }

    fun buildBtn(i: Int): RectF {
        val p = panelRect()
        val l = p.left + 12f + i * 169f
        return RectF(l, p.top + 14f, l + 160f, p.bottom - 14f)
    }

    fun upgradeBtn(): RectF {
        val p = panelRect()
        return RectF(p.left + 250f, p.top + 14f, p.left + 480f, p.bottom - 14f)
    }

    fun sellBtn(): RectF {
        val p = panelRect()
        return RectF(p.left + 496f, p.top + 14f, p.left + 676f, p.bottom - 14f)
    }

    fun spawning() = pending.isNotEmpty()

    // ───── التقدّم المحفوظ ─────
    fun starsOf(i: Int) = prefs.getInt("stars$i", 0)
    fun isUnlocked(i: Int) = i == 0 || starsOf(i - 1) > 0

    // ───── التحكم بالحالة ─────
    fun startLevel(i: Int) {
        levelIdx = i
        level = Levels.all[i]
        gold = level.startGold
        lives = level.lives
        waveNum = 0
        speed = 1
        countdown = 20f
        clock = 0f
        stars = 0
        enemies.clear(); towers.clear(); projectiles.clear()
        particles.clear(); bolts.clear(); texts.clear(); pending.clear()
        spotTower = arrayOfNulls(level.spots.size)
        selSpot = -1
        selTower = null
        state = State.PLAYING
    }

    fun onAppPause() {
        if (state == State.PLAYING) state = State.PAUSED
    }

    fun onBack(): Boolean = when (state) {
        State.PLAYING -> { state = State.PAUSED; true }
        State.PAUSED -> { state = State.PLAYING; true }
        State.WON, State.LOST -> { state = State.MENU; true }
        State.MENU -> false
    }

    private fun callNextWave(early: Boolean) {
        if (waveNum >= level.waves) return
        if (early && pending.isEmpty()) gold += (countdown / 2f).toInt()
        waveNum++
        pending.addAll(Levels.wave(waveNum, level, clock))
        countdown = 18f
    }

    // ───── الإدخال ─────
    fun onTap(x: Float, y: Float) {
        when (state) {
            State.MENU -> {
                for (i in Levels.all.indices) {
                    if (levelRect(i).contains(x, y) && isUnlocked(i)) {
                        startLevel(i)
                        return
                    }
                }
            }
            State.PLAYING -> tapPlaying(x, y)
            State.PAUSED -> {
                if (pauseResume.contains(x, y)) state = State.PLAYING
                else if (pauseRestart.contains(x, y)) startLevel(levelIdx)
                else if (pauseMenu.contains(x, y)) state = State.MENU
            }
            State.WON -> {
                if (endBtn1.contains(x, y)) {
                    if (levelIdx + 1 < Levels.all.size) startLevel(levelIdx + 1) else startLevel(levelIdx)
                } else if (endBtn2.contains(x, y)) state = State.MENU
            }
            State.LOST -> {
                if (endBtn1.contains(x, y)) startLevel(levelIdx)
                else if (endBtn2.contains(x, y)) state = State.MENU
            }
        }
    }

    private fun tapPlaying(x: Float, y: Float) {
        if (pauseBtn.contains(x, y)) { state = State.PAUSED; return }
        if (speedBtn.contains(x, y)) { speed = if (speed == 1) 2 else 1; return }
        if (waveNum < level.waves && nextBtn.contains(x, y)) { callNextWave(true); return }
        if (panelVisible() && panelRect().contains(x, y)) { tapPanel(x, y); return }

        for (i in level.spots.indices) {
            val s = level.spots[i]
            if (hypot(x - s.x, y - s.y) < 40f) {
                val t = spotTower[i]
                if (t != null) { selTower = t; selSpot = -1 } else { selSpot = i; selTower = null }
                return
            }
        }
        selSpot = -1
        selTower = null
    }

    private fun tapPanel(x: Float, y: Float) {
        if (selSpot >= 0) {
            val types = TowerType.values()
            for (i in types.indices) {
                if (buildBtn(i).contains(x, y)) { build(types[i]); return }
            }
        } else {
            val t = selTower ?: return
            if (t.canUpgrade() && upgradeBtn().contains(x, y)) upgrade(t)
            else if (sellBtn().contains(x, y)) sell(t)
        }
    }

    private fun build(type: TowerType) {
        val cost = type.levels[0].cost
        if (selSpot < 0 || gold < cost) return
        val sp = level.spots[selSpot]
        val t = Tower(type, sp.x, sp.y, selSpot)
        gold -= cost
        towers.add(t)
        spotTower[selSpot] = t
        burst(sp.x, sp.y, type.color, 14)
        selSpot = -1
        selTower = t
    }

    private fun upgrade(t: Tower) {
        if (!t.canUpgrade()) return
        val cost = t.upgradeCost()
        if (gold < cost) return
        gold -= cost
        t.invested += cost
        t.level++
        burst(t.x, t.y - 10f, 0xFFFFD54F.toInt(), 16)
    }

    private fun sell(t: Tower) {
        gold += t.sellValue()
        towers.remove(t)
        spotTower[t.spot] = null
        burst(t.x, t.y, 0xFFFFD54F.toInt(), 10)
        selTower = null
    }

    // ───── التحديث ─────
    fun update(dt: Float) {
        time += dt
        if (state != State.PLAYING) return
        clock += dt

        // الموجات
        if (waveNum < level.waves && pending.isEmpty()) {
            countdown -= dt
            if (countdown <= 0f) callNextWave(false)
        }
        if (pending.isNotEmpty()) {
            val it = pending.iterator()
            while (it.hasNext()) {
                val s = it.next()
                if (s.at <= clock) {
                    enemies.add(Enemy(s.type, s.type.hp * s.hpScale, level.path[0]))
                    it.remove()
                }
            }
        }

        // الأعداء
        for (e in enemies) {
            if (!e.alive) continue
            e.update(dt, level.path)
            if (e.reached) {
                lives -= e.type.damage
                burst(e.x, e.y, 0xFFE53935.toInt(), 14)
            }
        }
        enemies.removeAll { !it.alive || it.reached }
        if (lives <= 0) {
            lives = 0
            state = State.LOST
            return
        }

        // الأبراج
        for (t in towers) {
            t.cd -= dt
            val target = findTarget(t)
            if (target != null) {
                t.angle = atan2(target.y - t.y, target.x - t.x)
                if (t.cd <= 0f) {
                    fire(t, target)
                    t.cd = t.stats.cooldown
                }
            }
        }

        // المقذوفات
        for (p in projectiles) {
            val tg = p.target
            if (tg != null && tg.alive) {
                p.tx = tg.x
                p.ty = tg.y
            }
            val dx = p.tx - p.x
            val dy = p.ty - p.y
            val d = hypot(dx, dy)
            val step = p.speed * dt
            if (d <= step) {
                impact(p)
                p.dead = true
            } else {
                p.x += dx / d * step
                p.y += dy / d * step
            }
        }
        projectiles.removeAll { it.dead }
        enemies.removeAll { !it.alive }

        // المؤثرات
        for (pt in particles) { pt.x += pt.vx * dt; pt.y += pt.vy * dt; pt.life -= dt }
        particles.removeAll { it.life <= 0f }
        for (b in bolts) b.life -= dt
        bolts.removeAll { it.life <= 0f }
        for (f in texts) { f.y -= 30f * dt; f.life -= dt }
        texts.removeAll { it.life <= 0f }

        // الفوز
        if (waveNum >= level.waves && pending.isEmpty() && enemies.isEmpty()) win()
    }

    private fun win() {
        val frac = lives.toFloat() / level.lives
        stars = if (frac >= 0.9f) 3 else if (frac >= 0.5f) 2 else 1
        if (stars > starsOf(levelIdx)) prefs.edit().putInt("stars$levelIdx", stars).apply()
        state = State.WON
    }

    private fun canTarget(t: Tower, e: Enemy) = e.alive && (!e.type.flying || t.type.hitsAir)

    private fun findTarget(t: Tower): Enemy? {
        val r = t.stats.range
        var best: Enemy? = null
        for (e in enemies) {
            if (!canTarget(t, e)) continue
            val d = hypot(e.x - t.x, e.y - t.y)
            if (d <= r + e.type.radius && (best == null || e.dist > best.dist)) best = e
        }
        return best
    }

    private fun fire(t: Tower, e: Enemy) {
        val s = t.stats
        if (t.type == TowerType.MAGE) {
            zap(t, e)
            return
        }
        val spd = when (t.type) {
            TowerType.ARCHER -> 650f
            TowerType.CANNON -> 360f
            else -> 480f
        }
        projectiles.add(Projectile(t.x, t.y - 16f, e, s.damage, s.splash, s.slow, spd, t.type))
    }

    private fun zap(t: Tower, first: Enemy) {
        val s = t.stats
        val xs = ArrayList<Float>()
        val ys = ArrayList<Float>()
        xs.add(t.x); ys.add(t.y - 24f)
        val done = HashSet<Enemy>()
        var cur: Enemy? = first
        var n = 0
        while (cur != null && n < s.chain) {
            done.add(cur)
            xs.add(cur.x); ys.add(cur.y)
            hit(cur, s.damage)
            n++
            var nxt: Enemy? = null
            var bd = 130f
            for (e in enemies) {
                if (!e.alive || e in done) continue
                val d = hypot(e.x - cur.x, e.y - cur.y)
                if (d < bd) { bd = d; nxt = e }
            }
            cur = nxt
        }
        bolts.add(Bolt(xs.toFloatArray(), ys.toFloatArray(), 0.18f))
    }

    private fun impact(p: Projectile) {
        if (p.splash > 0f) {
            for (e in enemies) {
                if (!e.alive) continue
                if (e.type.flying && !p.kind.hitsAir) continue
                if (hypot(e.x - p.tx, e.y - p.ty) <= p.splash + e.type.radius) {
                    hit(e, p.damage)
                    if (p.slow > 0f) e.slow(p.slow, 1.8f)
                }
            }
            val c = if (p.kind == TowerType.CANNON) 0xFFFFB74D.toInt() else 0xFF81D4FA.toInt()
            burst(p.tx, p.ty, c, 12)
        } else {
            val tg = p.target
            if (tg != null && tg.alive) {
                hit(tg, p.damage)
                if (p.slow > 0f) tg.slow(p.slow, 1.8f)
            }
            burst(p.tx, p.ty, 0xFFFFE0B2.toInt(), 3)
        }
    }

    private fun hit(e: Enemy, dmg: Float) {
        if (!e.alive) return
        e.hp -= dmg
        e.flash = 0.1f
        if (e.hp <= 0f) {
            e.alive = false
            gold += e.type.reward
            texts.add(FloatText(e.x, e.y - 20f, "+${e.type.reward}", 0.9f, 0xFFFFD54F.toInt()))
            burst(e.x, e.y, e.type.color, 10)
        }
    }

    private fun burst(x: Float, y: Float, color: Int, n: Int) {
        repeat(n) {
            val a = rnd.nextFloat() * 6.2832f
            val sp = 40f + rnd.nextFloat() * 120f
            particles.add(Particle(x, y, cos(a) * sp, sin(a) * sp, 0.5f, 0.5f, color, 3f + rnd.nextFloat() * 3f))
        }
    }
}
